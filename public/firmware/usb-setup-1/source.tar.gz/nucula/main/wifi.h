#pragma once

#include "esp_err.h"
#include "freertos/FreeRTOS.h"
#include "freertos/event_groups.h"
#include <stdbool.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

#define WIFI_CONNECTED_BIT BIT0

/**
 * Initialize WiFi in station mode and start the supervisor task.
 *
 * Spawns a long-lived FreeRTOS task that, while disconnected, periodically
 * re-tries esp_wifi_connect(). The initial connect attempt blocks for up to
 * 15 seconds; if it does not succeed in that window the function returns
 * ESP_FAIL while the supervisor keeps trying in the background.
 *
 * Safe to call only once.
 *
 * @return ESP_OK if connected within 15 s, ESP_FAIL otherwise
 */
esp_err_t wifi_init(void);

/* Persist credentials for the next boot, separately from wallet data.
 * Passwords are never returned by the USB setup protocol. */
esp_err_t wifi_save_credentials(const char *ssid, const char *password);
bool wifi_setup_configured(void);
bool wifi_setup_restart_required(void);
void wifi_setup_ssid(char *out, size_t size);
void wifi_setup_ip(char *out, size_t size);

/**
 * Returns true if WiFi is connected and the device has an IP address.
 */
bool wifi_is_connected(void);

/**
 * Toggle radio power save. Default is WIFI_PS_MIN_MODEM (doze between DTIM
 * beacons, ~100-300 ms first-packet latency). Pass true to disable power
 * save for a latency-critical window (an active NFC payment), false to
 * restore it.
 */
void wifi_set_low_latency(bool on);

/**
 * Returns the FreeRTOS event group whose WIFI_CONNECTED_BIT is set whenever
 * the device is associated and has an IP, and cleared on disconnect. Other
 * tasks can wait on this bit to react to (re)connection events.
 */
EventGroupHandle_t wifi_get_event_group(void);

#ifdef __cplusplus
}
#endif
